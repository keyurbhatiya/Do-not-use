// 29. Write a program to replace a character in given string.


#include <stdio.h>

void replaceCharacter(char str[], char oldChar, char newChar) {
    int i = 0;
    
    while (str[i] != '\0') {
        if (str[i] == oldChar) {
            str[i] = newChar;  
        }
        i++;
    }
}

int main() {
    char str[100], oldChar, newChar;

    printf("Enter a string: ");
    fgets(str, sizeof(str), stdin);

    printf("Enter the character to replace: ");
    scanf("%c", &oldChar);  
    getchar();  

    printf("Enter the new character: ");
    scanf("%c", &newChar);  

    // Call the function to replace the character
    replaceCharacter(str, oldChar, newChar);

    printf("Modified string: %s\n", str);

    return 0;
}
