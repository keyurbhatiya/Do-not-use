// 24. Write a program to print following patterns :  1 to 5


#include <stdio.h>

void pattern_i(int n) {
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= i; j++) {
            printf("%d", j);  
        }
        printf("\n");  
    }
}

void pattern_ii(int n) {
    for (int i = n; i >= 1; i--) {
        for (int j = 1; j <= i; j++) {
            printf("%d", j);
        }
        printf("\n");
    }
}

void pattern_iii(int n) {
    for (int i = n; i >= 1; i--) {  
       
        for (int j = 1; j <= n - i; j++) {
            printf(" ");
        }
        
        for (int j = 1; j <= i; j++) {
            printf("%d", i);
        }
        
        printf("\n");  
    }
}

void pattern_iv(int n) {
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= i; j++) {
            printf("%d", i);
        }
        printf("\n");
    }
}

int main() {
    int n = 5;  

    printf("Pattern i:\n");
    pattern_i(n);

    printf("\nPattern ii:\n");
    pattern_ii(n);

    printf("\nPattern iii:\n");
    pattern_iii(n);

    printf("\nPattern iv:\n");
    pattern_iv(n);

    return 0;
}
