// 27. Write a program to find maximum element from 1-Dimensional array.


#include <stdio.h>

#define SIZE 10  

int main() {
    int arr[SIZE];  // Declare the array
    int i, max;

    printf("Enter %d elements:\n", SIZE);
    for (i = 0; i < SIZE; i++) {
        printf("Element %d: ", i + 1);
        scanf("%d", &arr[i]);
    }

    max = arr[0];

    for (i = 1; i < SIZE; i++) {
        if (arr[i] > max) {
            max = arr[i];
        }
    }

    printf("\nThe maximum element in the array is: %d\n", max);

    return 0;
}
