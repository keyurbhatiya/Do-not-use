// 1. Write a program to that performs as calculator (addition, multiplication, division, subtraction).

#include <stdio.h>

int main() {
    char op;            // To store the operator
    int num1, num2;     // To store the two numbers
    int result;         // To store the result

    printf("Enter an operator (+, -, *, /): ");
    scanf(" %c", &op);

    printf("Enter the first number: ");
    scanf("%d", &num1);
    printf("Enter the second number: ");
    scanf("%d", &num2);

    // Perform the calculation
    if (op == '+') {
        result = num1 + num2;
        printf("Result: %d\n", result);
    } else if (op == '-') {
        result = num1 - num2;
        printf("Result: %d\n", result);
    } else if (op == '*') {
        result = num1 * num2;
        printf("Result: %d\n", result);
    } else if (op == '/') {
        if (num2 != 0) {
            result = num1 / num2;
            printf("Result: %d\n", result);
        } else {
            printf("Error: Cannot divide by zero.\n");
        }
    } else {
        printf("Error: Invalid operator.\n");
    }

    return 0;
}
