// 22. Write a C program to find 1+1/2! +1/3! +1/4! +...... +1/n!


#include <stdio.h>

// Function to calculate factorial
long long factorial(int num) {
    long long fact = 1;
    for (int i = 1; i <= num; i++) {
        fact *= i;
    }
    return fact;
}

int main() {
    int n;
    double sum = 1.0;  

    printf("Enter the value of n: ");
    scanf("%d", &n);

    for (int i = 2; i <= n; i++) {
        sum += 1.0 / factorial(i);  // Add the next term (1/i!)
    }

    printf("The sum of the series is: %.6f\n", sum);

    return 0;
}
