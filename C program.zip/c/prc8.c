// 8. Write a program to read marks of a student from keyboard whether the student is pass or fail
//    (using if else)

#include <stdio.h>

int main() {
    int marks;

    printf("Enter the marks of the student: ");
    scanf("%d", &marks);

    // Check if the student passed or failed
    if (marks >= 50) {
        printf("The student has passed.\n");
    } else {
        printf("The student has failed.\n");
    }

    return 0;
}
