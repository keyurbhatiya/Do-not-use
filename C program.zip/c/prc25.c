// 25. Write a program to print following patterns:  ABCD


#include <stdio.h>

void pattern_i(int n) {
    for (int i = 0; i < n; i++) {
        
        for (char ch = 'A'; ch < 'A' + (n - i); ch++) {
            printf("%c", ch);
        }
        printf("\n");  
    }
}

void pattern_ii(int n) {
    for (int i = 0; i < n; i++) {
        
        for (char ch = 'A'; ch < 'A' + (n - i); ch++) {
            printf("%c", ch);
        }
        printf("\n");  
    }
}

int main() {
    int n = 5;  

    printf("Pattern i:\n");
    pattern_i(n);

    printf("\nPattern ii:\n");
    pattern_ii(n);

    return 0;
}
