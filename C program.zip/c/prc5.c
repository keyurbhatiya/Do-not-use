// 5. Write a C program to enter a distance in to kilometre and convert it in to meter, feet,inches and
//    centimetre.

#include <stdio.h>

int main() {
    float kilometers, meters, feet, inches, centimeters;

    printf("Enter the distance in kilometers: ");
    scanf("%f", &kilometers);

    meters = kilometers * 1000;          // 1 kilometer = 1000 meters
    centimeters = meters * 100;          // 1 meter = 100 centimeters
    inches = meters * 39.3701;           // 1 meter = 39.3701 inches
    feet = meters * 3.28084;             // 1 meter = 3.28084 feet

    printf("Distance in meters: %.2f m\n", meters);
    printf("Distance in centimeters: %.2f cm\n", centimeters);
    printf("Distance in feet: %.2f ft\n", feet);
    printf("Distance in inches: %.2f in\n", inches);

    return 0;
}
