// 17. Write a program to generate first n number of Fibonacci series


#include <stdio.h>

int main() {
    int n, first = 0, second = 1, next;

    printf("Enter the number of terms in the Fibonacci series: ");
    scanf("%d", &n);

    if (n <= 0) {
        printf("Please enter a positive number.\n");
    } else {
        printf("Fibonacci series: ");

        for (int i = 1; i <= n; i++) {
            if (i == 1) {
                printf("%d ", first); // Print the first term
                continue;
            }
            if (i == 2) {
                printf("%d ", second); // Print the second term
                continue;
            }

            next = first + second; // Calculate the next term
            printf("%d ", next);

            first = second;
            second = next;
        }
        printf("\n");
    }

    return 0;
}
